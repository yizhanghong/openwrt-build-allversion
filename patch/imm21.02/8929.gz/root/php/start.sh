#!/bin/bash
php-cli -S 0.0.0.0:8880 /root/php/index.php  &
