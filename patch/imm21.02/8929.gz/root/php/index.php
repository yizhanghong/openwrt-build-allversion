<?php
// 设置错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);
// 设置无限制执行时间
set_time_limit(0);
// 禁用输出缓冲
ini_set('output_buffering', 'Off');
ini_set('zlib.output_compression', 0);

// 日志函数
function writeLog($message) {
    $logFile = 'access.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

// 获取请求的文件名
$requestUri = $_SERVER['REQUEST_URI'];
$filename = basename($requestUri);

// 记录请求信息
writeLog("Request: " . $filename . " from " . $_SERVER['REMOTE_ADDR']);

// 如果有具体的文件名请求
if (preg_match('/^\d{8}\./', $filename)) {
    $searchPattern = substr($filename, 0, 8);  // 获取前8位数字
} else {
    writeLog("Error: Invalid filename format - Filename must start with 8 digits");
    header("HTTP/1.0 404 Not Found");
    exit("File not found");
}

// 数据库配置
$config = [
    'host' => 'ca.vodip.cn',
    'port' => 3336,
    'dbname' => 'eVideoKTV',
    'username' => 'admin',
    'password' => 'admin'
];

try {
    // 连接数据库
    $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['dbname']}";
    $pdo = new PDO($dsn, $config['username'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 准备SQL查询，使用文件名前8位
    $sql = "SELECT CONCAT('http://',c.IP1,':9166', b.pathname,a.filename) as down 
            FROM FY_SONGFILE AS a 
            LEFT JOIN FY_PATH AS b ON a.PathID=b.PathSerialNo 
            LEFT JOIN FY_SERVER AS c ON b.ServerID=c.ID 
            WHERE FileName LIKE '" . $searchPattern . "%'";

    // 记录SQL查询
    writeLog("SQL: " . $sql);

    // 执行查询
    $stmt = $pdo->query($sql);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        $url = $result['down'];
        // 记录查询结果
        writeLog("Result URL: " . $url);

        // 初始化 CURL
        $ch = curl_init();
        
        // 获取文件大小
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_exec($ch);
        $fileSize = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        
        // 处理断点续传
        $start = 0;
        $end = $fileSize - 1;
        
        if (isset($_SERVER['HTTP_RANGE'])) {
            list($start) = sscanf($_SERVER['HTTP_RANGE'], "bytes=%d-");
            if ($start === null) $start = 0;
            
            header('HTTP/1.1 206 Partial Content');
            header("Content-Range: bytes $start-$end/$fileSize");
        } else {
            header('HTTP/1.1 200 OK');
        }
        
        // 设置响应头
        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        $contentType = 'application/octet-stream';
        if ($extension === 'ts') {
            $contentType = 'video/mp2t';
        }
        
        header("Content-Type: $contentType");
        header("Content-Length: " . ($end - $start + 1));
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Accept-Ranges: bytes");
        
        // 重置 CURL 选项用于下载
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_NOBODY, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RANGE, $start . "-" . $end);
        
        // 设置写入回调函数
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) {
            echo $data;
            flush();
            return strlen($data);
        });
        
        writeLog("Start streaming file from position: " . $start);
        
        // 执行下载
        curl_exec($ch);
        
        // 检查是否有错误
        if (curl_errno($ch)) {
            writeLog("Curl error: " . curl_error($ch));
            header("HTTP/1.0 500 Internal Server Error");
            exit("Download failed");
        }
        
        curl_close($ch);
        writeLog("Completed streaming file: " . $filename);
        exit;
    } else {
        writeLog("Error: No results found for pattern: " . $searchPattern);
        header("HTTP/1.0 404 Not Found");
        exit("File not found");
    }

} catch (Exception $e) {
    writeLog("Error: " . $e->getMessage());
    header("HTTP/1.0 500 Internal Server Error");
    exit("Error: " . $e->getMessage());
} 
