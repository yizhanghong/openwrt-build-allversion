#!/bin/bash

# 查找监听端口 8880 的进程ID
pid=$(netstat -lnutp | grep ':8880' | awk '{print $7}' | cut -d'/' -f1)

# 如果找到了进程ID，则杀死该进程
if [ -n "$pid" ]; then
  echo "找到监听端口 8880 的进程，进程ID为 $pid，正在终止..."
  kill -9 $pid
  echo "进程已终止。"
else
  echo "未找到监听端口 8880 的进程。"
fi

